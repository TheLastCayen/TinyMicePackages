#!/bin/bash

# Uninstall Launcher
rm -f /usr/share/applications/TinyMouse.desktop

# Uninstall symbolic lync
rm -f /usr/share/pixmaps/inymice.png 
rm -f /usr/bin/tinymice

# Uninstall hicolor icon
rm -f /usr/share/icons/hicolor/128x128/apps/tinymice.png

# Uninstall TinyMice
rm -RF /usr/share/tinymice



